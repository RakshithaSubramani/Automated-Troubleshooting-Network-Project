import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split, GridSearchCV, cross_val_score
from sklearn.metrics import classification_report, confusion_matrix
from sklearn.preprocessing import LabelEncoder
from sklearn.utils.class_weight import compute_class_weight
import warnings
import os
import joblib
import logging

# Set up logging
logging.basicConfig(filename='training_log.log', level=logging.INFO,
                    format='%(asctime)s - %(levelname)s - %(message)s')
warnings.filterwarnings('ignore')

# Load the dataset
file_path = r"C:\Users\priya\Downloads\archive_1\p3.csv"  # Ensure this is the correct path
logging.info(f"Attempting to load dataset from: {file_path}")
try:
    df = pd.read_csv(file_path)
    logging.info("Dataset loaded successfully.")
except FileNotFoundError:
    logging.error(f"Dataset not found at {file_path}. Please verify the path.")
    raise
except Exception as e:
    logging.error(f"Error loading dataset: {e}")
    raise

print("Current working directory:", os.getcwd())  # Verify where the model will be saved

# Step 1: Sample the dataset
sample_size = 634316  # Adjusted to match your dataset size or max rows
if len(df) < sample_size:
    logging.warning(f"Requested sample size ({sample_size}) exceeds dataset size ({len(df)}). Using full dataset.")
    df_sampled = df
else:
    df_sampled = df.sample(n=sample_size, random_state=42)  # Random sample
logging.info(f"Sampled {len(df_sampled)} rows from dataset.")

# Step 2: Preprocess the Data
# Handle missing values
df_sampled = df_sampled.fillna(0)  # Replace NaN with 0; adjust based on context
logging.info("Missing values filled with 0.")

# Convert categorical columns to numeric with a new LabelEncoder for each column
le_dict = {}
categorical_columns = ["Source", "Destination", "Protocol", "Info"]
for column in categorical_columns:
    le_dict[column] = LabelEncoder()
    df_sampled[column] = le_dict[column].fit_transform(df_sampled[column].astype(str))
    logging.info(f"Encoded {column} with classes: {le_dict[column].classes_[:5]}...")

# Convert time-related columns to numeric
time_columns = ["Time", "delta_time", "abs_time", "rel_time", "utc_time", "cumilative_bytes",
                "exp_inf_sev", "fw1_mon_if_dir", "RSSI", "TX_rate", "IPDSCP_val", "packet_length"]
for column in time_columns:
    if column in df_sampled.columns:
        if column == "Time":
            df_sampled[column] = pd.to_datetime(df_sampled[column], errors='coerce').astype('int64') // 10**9  # Convert to seconds
        else:
            df_sampled[column] = pd.to_numeric(df_sampled[column], errors='coerce').fillna(0)
logging.info("Converted time-related and numeric columns to appropriate types.")

# Select features
features = ["delta_time", "Length", "abs_time", "rel_time", "cumilative_bytes",
            "exp_inf_sev", "fw1_mon_if_dir", "RSSI", "TX_rate", "IPDSCP_val", "packet_length",
            "Source", "Destination", "Protocol", "Info"]
X = df_sampled[features]
logging.info(f"Selected features: {features}")

# Step 3: Label the Data with Specific Issues
def label_specific(row):
    info_text = str(row["Info"]).lower()  # Ensure case-insensitive matching
    if "out of order" in info_text:
        return "packet_disorder"
    elif "retransmission" in info_text or "lost_segment" in info_text:
        return "packet_loss"
    elif pd.to_numeric(row["RSSI"], errors='coerce') < -70:
        return "signal_issue"
    elif pd.to_numeric(row["Length"], errors='coerce') > 150 and pd.to_numeric(row["delta_time"], errors='coerce') > 0.005:
        return "congestion"
    elif pd.to_numeric(row["delta_time"], errors='coerce') > 0.01:
        return "high_latency"
    else:
        return "normal"

df_sampled["label"] = df_sampled.apply(label_specific, axis=1)
y = df_sampled["label"]
logging.info("Labels assigned. Label distribution:\n" + str(y.value_counts()))

# Step 4: Split the Data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)
logging.info("Data split into training and test sets (80-20 split).")

# Step 5: Compute class weights for imbalance
class_weights = compute_class_weight('balanced', classes=np.unique(y), y=y)
class_weight_dict = dict(zip(np.unique(y), class_weights))
logging.info(f"Computed class weights: {class_weight_dict}")

# Step 6: Load existing model if available, otherwise train new
try:
    existing_model = joblib.load('random_forest_model.pkl')
    logging.info("Loaded existing model. Using its best parameters as a starting point.")
    best_params = existing_model.get_params()
    rf = RandomForestClassifier(**best_params, random_state=42, class_weight=class_weight_dict)
except FileNotFoundError:
    logging.info("No existing model found. Training new model.")
    rf = RandomForestClassifier(random_state=42, class_weight=class_weight_dict)

# Tune the model
param_grid = {
    'n_estimators': [100, 200],
    'max_depth': [10, 20, 30, None],
    'min_samples_split': [2, 5, 10],
    'min_samples_leaf': [1, 2, 4]
}

grid_search = GridSearchCV(estimator=rf, param_grid=param_grid, cv=5, n_jobs=-1, verbose=2)
grid_search.fit(X_train, y_train)
logging.info(f"Grid search completed. Best parameters: {grid_search.best_params_}")

# Best model
best_model = grid_search.best_estimator_
print("Best Parameters:", grid_search.best_params_)

# Step 7: Evaluate the Model
y_pred = best_model.predict(X_test)
print("\nClassification Report:\n", classification_report(y_test, y_pred))
print("Confusion Matrix:\n", confusion_matrix(y_test, y_pred))
logging.info("Model evaluation completed. Classification report and confusion matrix logged.")

# Cross-validation score
cv_scores = cross_val_score(best_model, X, y, cv=5)
print("Cross-Validation Scores:", cv_scores)
print("Mean CV Score:", cv_scores.mean())
logging.info(f"Cross-validation scores: {cv_scores}, Mean: {cv_scores.mean()}")

# Feature Importance
importances = best_model.feature_importances_
feature_importance = dict(zip(features, importances))
print("\nFeature Importance:", feature_importance)
logging.info(f"Feature importance: {feature_importance}")

# Step 8: Infer Specific Issues (Post-Prediction)
def infer_issue(row, prediction, importances):
    info_text = str(row["Info"]).lower()
    if prediction != "normal":
        if importances["delta_time"] > 0.5 and pd.to_numeric(row["delta_time"], errors='coerce') > 0.01:
            return "high_latency"
        elif importances.get("Info", 0) > 0.3 and "out of order" in info_text:
            return "packet_disorder"
        elif importances.get("Info", 0) > 0.3 and ("retransmission" in info_text or "lost_segment" in info_text):
            return "packet_loss"
        elif importances["Length"] > 0.4 and pd.to_numeric(row["Length"], errors='coerce') > 150 and pd.to_numeric(row["delta_time"], errors='coerce') > 0.005:
            return "congestion"
        elif importances["RSSI"] > 0.3 and pd.to_numeric(row["RSSI"], errors='coerce') < -70:
            return "signal_issue"
        else:
            return "unknown_problem"
    return prediction

# Apply inference to test set
inferences = [infer_issue(row, pred, feature_importance) for row, pred in zip(X_test.to_dict('records'), y_pred)]
print("\nInferred Issues for Test Set (first 10):", inferences[:10])
logging.info("Inferred issues for test set (first 10): " + str(inferences[:10]))

# Step 9: Save the Model and Predictions
output_dir = "model_outputs"
os.makedirs(output_dir, exist_ok=True)
joblib.dump(best_model, os.path.join(output_dir, 'random_forest_model.pkl'))
joblib.dump(feature_importance, os.path.join(output_dir, 'feature_importance.pkl'))
for column, le in le_dict.items():
    joblib.dump(le, os.path.join(output_dir, f'le_{column}.pkl'))
df_sampled["predicted_label"] = best_model.predict(X)
df_sampled["inferred_issue"] = [infer_issue(row, pred, feature_importance) for row, pred in zip(df_sampled[features].to_dict('records'), df_sampled["predicted_label"])]
df_sampled.to_csv(os.path.join(output_dir, "predicted_kaggle_file_100000.csv"), index=False)
logging.info("Model, label encoders, feature importance, and predictions saved to 'model_outputs' directory.")

print("Model training and prediction complete with 100,000 samples. Check 'model_outputs' directory for results and 'training_log.log' for details.")