import pandas as pd
import numpy as np
from sklearn.preprocessing import LabelEncoder
import joblib

# Load the saved model, feature importances, and label encoder
model_path = "random_forest_model.pkl"
feature_importance_path = "feature_importance.pkl"
label_encoder_path = "label_encoder.pkl"

try:
    loaded_model = joblib.load(model_path)
    feature_importance = joblib.load(feature_importance_path)
    le = joblib.load(label_encoder_path)
    print("Model, feature importances, and label encoder loaded successfully.")
except FileNotFoundError as e:
    print(f"Error: {e}. Please ensure the files exist in the current directory.")
    exit()

# Define the feature names (must match training features with original spelling)
features = ["delta_time", "Length", "abs_time", "rel_time", "cumilative_bytes",
            "exp_inf_sev", "fw1_mon_if_dir", "RSSI", "TX_rate", "IPDSCP_val",
            "packet_length", "Source", "Destination", "Protocol", "Info"]

# Prepare a sample input designed for congestion
sample_input = {
    "delta_time": 0.007,     # Between 0.005 and 0.01 to trigger congestion
    "Length": 200,          # > 150 to trigger congestion
    "abs_time": 503,        # Example from Row 5
    "rel_time": 0.007,      # Matches delta_time
    "cumilative_bytes": 615, # Example from Row 5
    "exp_inf_sev": 0,       # Assuming 0
    "fw1_mon_if_dir": 0,    # Assuming 0
    "RSSI": 0,              # Assuming 0
    "TX_rate": 0,           # Assuming 0
    "IPDSCP_val": 0,        # Assuming numeric
    "packet_length": 200,   # Matches Length
    "Source": "[TCP Window Update] 443 > 61666 [ACK] Seq=1307344 Ack=559372 Win=877824 Len=0 SLE=568840 SRE=570232",  # Trained class
    "Destination": "[TCP Window Update] 443 > 61666 [ACK] Seq=1307344 Ack=559372 Win=877824 Len=0 SLE=568840 SRE=570232",  # Trained class
    "Protocol": "[TCP Window Update] 443 > 61666 [ACK] Seq=1307344 Ack=559372 Win=877824 Len=0 SLE=568840 SRE=570232",  # Trained class
    "Info": "[TCP Window Update] 443 > 61666 [ACK] Seq=1307344 Ack=559372 Win=877824 Len=0 SLE=568840 SRE=570232",  # Trained class
    "Time": "2023-01-01 12:00:00",  # Sample timestamp
    "utc_time": 1672579200   # Sample Unix timestamp
}

# Preprocess the sample input
sample_input_df = pd.DataFrame([sample_input])

# Validate and transform categorical variables using the trained LabelEncoder
categorical_columns = ["Source", "Destination", "Protocol", "Info"]
for column in categorical_columns:
    trained_classes = le.classes_ if hasattr(le, 'classes_') else np.array([])
    input_values = sample_input_df[column].astype(str).values
    valid_mask = np.isin(input_values, trained_classes)
    if not valid_mask.all():
        print(f"Warning: Unseen labels in {column}: {input_values[~valid_mask]}")
        print(f"Trained classes for {column}: {trained_classes[:5]}...")  # Show first 5 for brevity
        default_class = trained_classes[0] if len(trained_classes) > 0 else "unknown"
        sample_input_df.loc[~valid_mask, column] = default_class
        print(f"Replaced unseen labels with: {default_class}")
    sample_input_df[column] = le.transform(sample_input_df[column].astype(str))

# Convert time-related and numeric columns
sample_input_df["Time"] = pd.to_datetime(sample_input_df["Time"], errors='coerce').astype('int64') // 10**9
sample_input_df["delta_time"] = pd.to_numeric(sample_input_df["delta_time"], errors='coerce').fillna(0)
sample_input_df["abs_time"] = pd.to_numeric(sample_input_df["abs_time"], errors='coerce').fillna(0)
sample_input_df["rel_time"] = pd.to_numeric(sample_input_df["rel_time"], errors='coerce').fillna(0)
sample_input_df["utc_time"] = pd.to_numeric(sample_input_df["utc_time"], errors='coerce').fillna(0)
sample_input_df["cumilative_bytes"] = pd.to_numeric(sample_input_df["cumilative_bytes"], errors='coerce').fillna(0)
sample_input_df["exp_inf_sev"] = pd.to_numeric(sample_input_df["exp_inf_sev"], errors='coerce').fillna(0)
sample_input_df["fw1_mon_if_dir"] = pd.to_numeric(sample_input_df["fw1_mon_if_dir"], errors='coerce').fillna(0)
sample_input_df["IPDSCP_val"] = pd.to_numeric(sample_input_df["IPDSCP_val"], errors='coerce').fillna(0)
sample_input_df["packet_length"] = pd.to_numeric(sample_input_df["packet_length"], errors='coerce').fillna(0)

# Select only the feature columns used during training
X_test = sample_input_df[features]

# Make prediction
prediction = loaded_model.predict(X_test)
print("Predicted Label:", prediction[0])

# Updated infer_issue function with adjusted conditions
def infer_issue(row, prediction, importances):
    info_text = str(row["Info"]).lower()
    if prediction != "normal":
        if pd.to_numeric(row["delta_time"], errors='coerce') > 0.01:  # High latency
            return "high_latency"
        elif pd.to_numeric(row["Length"], errors='coerce') > 150 and pd.to_numeric(row["delta_time"], errors='coerce') > 0.005:  # Congestion
            return "congestion"
        elif "out of order" in info_text:  # Packet disorder
            return "packet_disorder"
        elif "retransmission" in info_text or "lost_segment" in info_text:  # Packet loss
            return "packet_loss"
        elif pd.to_numeric(row["RSSI"], errors='coerce') < -70:  # Signal issue
            return "signal_issue"
        else:
            return "unknown_problem"
    return prediction

inferred_issue = infer_issue(sample_input, prediction[0], feature_importance)
print("Inferred Issue:", inferred_issue)

# Optional: Predict probability for confidence
prediction_proba = loaded_model.predict_proba(X_test)
print("\nPrediction Probabilities:")
for label, prob in zip(loaded_model.classes_, prediction_proba[0]):
    print(f"{label:15}: {prob:.4f}")