import pandas as pd
import numpy as np
import joblib
import pyshark
import os

# Load the saved model, feature importances, and individual label encoders
model_path = os.path.join('model_outputs', 'random_forest_model.pkl')
feature_importance_path = os.path.join('model_outputs', 'feature_importance.pkl')
label_encoder_paths = {
    'Source': os.path.join('model_outputs', 'le_Source.pkl'),
    'Destination': os.path.join('model_outputs', 'le_Destination.pkl'),
    'Protocol': os.path.join('model_outputs', 'le_Protocol.pkl'),
    'Info': os.path.join('model_outputs', 'le_Info.pkl')  # Re-added to match training
}

try:
    loaded_model = joblib.load(model_path)
    feature_importance = joblib.load(feature_importance_path)
    le_dict = {col: joblib.load(path) for col, path in label_encoder_paths.items()}
    print("Model, feature importances, and label encoders loaded successfully.")
    for col, le in le_dict.items():
        print(f"Trained Classes for {col}: {le.classes_[:5]}...")
except FileNotFoundError as e:
    print(f"Error: {e}. Please ensure the files exist in the 'model_outputs' directory.")
    exit()
except Exception as e:
    print(f"Error loading files: {e}")
    exit()

# Define the feature names (matching training, including Info)
features = ["delta_time", "Length", "abs_time", "rel_time", "cumilative_bytes",
            "exp_inf_sev", "fw1_mon_if_dir", "RSSI", "TX_rate", "IPDSCP_val",
            "packet_length", "Source", "Destination", "Protocol", "Info"]

# Configure latency threshold (in seconds)
HIGH_LATENCY_THRESHOLD = 0.04  # 40 ms as requested

# Initialize a capture with pyshark using the full path to tshark
cap = pyshark.LiveCapture(interface='5', tshark_path=r"C:\Program Files\Wireshark\tshark.exe", output_file=None)

print("Starting live packet capture. Press Ctrl+C to stop.")

# Function to extract features from a packet
def extract_features(packet):
    sample_input = {}
    
    # Time-related features using frame_info.time_delta for delta_time
    sample_input["Time"] = packet.sniff_time.strftime('%Y-%m-%d %H:%M:%S') if hasattr(packet, 'sniff_time') else "2023-01-01 12:00:00"
    sample_input["abs_time"] = packet.sniff_time.timestamp() if hasattr(packet, 'sniff_time') else 0.0
    sample_input["utc_time"] = int(sample_input["abs_time"])
    
    # Use frame_info.time_delta, default to 0.0 for first packet
    sample_input["delta_time"] = float(packet.frame_info.time_delta) if hasattr(packet.frame_info, 'time_delta') else 0.0
    sample_input["rel_time"] = sample_input["delta_time"]

    print(f"Debug - Delta Time from frame_info: {sample_input['delta_time']}")

    # Packet length
    sample_input["Length"] = int(packet.length) if hasattr(packet, 'length') else 200
    sample_input["packet_length"] = sample_input["Length"]

    # Cumulative bytes (approximate, incrementing per packet)
    if 'cumulative_bytes' not in globals():
        global cumulative_bytes
        cumulative_bytes = 0
    cumulative_bytes += sample_input["Length"]
    sample_input["cumilative_bytes"] = cumulative_bytes

    # Other numeric features (defaults since pyshark may not provide these directly)
    sample_input["exp_inf_sev"] = 0
    sample_input["fw1_mon_if_dir"] = 0
    sample_input["RSSI"] = int(packet.rssi) if hasattr(packet, 'rssi') else 0
    sample_input["TX_rate"] = 0
    sample_input["IPDSCP_val"] = 0

    # Categorical features with fallback to TCP ports
    try:
        sample_input["Source"] = str(getattr(packet.ipv6, 'src', getattr(packet.ip, 'src', getattr(packet.tcp, 'srcport', '')))) if hasattr(packet, 'ipv6') or hasattr(packet, 'ip') or hasattr(packet, 'tcp') else ''
    except AttributeError:
        sample_input["Source"] = str(getattr(packet.tcp, 'srcport', '')) if hasattr(packet, 'tcp') else ''
    try:
        sample_input["Destination"] = str(getattr(packet.ipv6, 'dst', getattr(packet.ip, 'dst', getattr(packet.tcp, 'dstport', '')))) if hasattr(packet, 'ipv6') or hasattr(packet, 'ip') or hasattr(packet, 'tcp') else ''
    except AttributeError:
        sample_input["Destination"] = str(getattr(packet.tcp, 'dstport', '')) if hasattr(packet, 'tcp') else ''
    
    protocol = 'UNKNOWN'
    if hasattr(packet, 'layers'):
        for layer in packet.layers:
            layer_name = layer.layer_name
            if layer_name in ['tcp', 'udp', 'icmpv6', 'icmp', 'arp', 'dhcp', 'dns', 'mdns']:
                protocol = layer_name.upper()
                break
    sample_input["Protocol"] = protocol
    
    sample_input["Info"] = str(getattr(packet, 'info', '')) if hasattr(packet, 'info') else ''  # Re-added for feature alignment

    return sample_input

# Process packets in real-time with debugging
try:
    print("Attempting to sniff packets...")
    for packet in cap.sniff_continuously(packet_count=10):
        print("Raw Packet:", packet)
        sample_input = extract_features(packet)
        sample_input_df = pd.DataFrame([sample_input])

        # Transform categorical variables using the loaded LabelEncoders
        categorical_columns = ["Source", "Destination", "Protocol", "Info"]
        has_unseen_labels = False
        for column in categorical_columns:
            try:
                le = le_dict[column]
                input_values = sample_input_df[column].astype(str).values
                valid_mask = np.isin(input_values, le.classes_)
                if not valid_mask.all():
                    has_unseen_labels = True
                    print(f"Warning: Unseen labels in {column}: {input_values[~valid_mask]}")
                    print(f"Trained classes for {column}: {le.classes_[:5]}...")
                    default_class = le.classes_[np.argmax(np.bincount(le.transform(le.classes_)))] if len(le.classes_) > 0 else 'unknown'
                    sample_input_df.loc[~valid_mask, column] = default_class
                    print(f"Replaced unseen labels with: {default_class}")
                sample_input_df[column] = le.transform(sample_input_df[column].astype(str))
            except ValueError as e:
                print(f"Error transforming {column}: {e}. Skipping prediction for this packet.")
                has_unseen_labels = True
            except KeyError as e:
                print(f"Missing LabelEncoder for {column}: {e}. Skipping prediction.")
                has_unseen_labels = True

        # Convert time-related and numeric columns
        sample_input_df["Time"] = pd.to_datetime(sample_input_df["Time"], errors='coerce').astype('int64') // 10**9
        for column in ["delta_time", "abs_time", "rel_time", "utc_time", "cumilative_bytes",
                      "exp_inf_sev", "fw1_mon_if_dir", "RSSI", "TX_rate", "IPDSCP_val", "packet_length"]:
            sample_input_df[column] = pd.to_numeric(sample_input_df[column], errors='coerce').fillna(0)

        # Select only the feature columns used during training
        X_test = sample_input_df[features]

        # Make prediction, allowing it to proceed with replaced unseen labels
        prediction = loaded_model.predict(X_test)[0] if len(X_test) > 0 and not X_test.empty else "N/A"
        print(f"\nPacket Captured at {sample_input['Time']}:")
        print(f"Delta Time: {sample_input['delta_time'] * 1000:.2f} ms")
        print("Predicted Label:", prediction)

        # Infer issue (keeping Info for basic rules, excluding packet loss)
        def infer_issue(row):
            info_text = str(row["Info"]).lower()
            delta_time = pd.to_numeric(row["delta_time"], errors='coerce')
            if delta_time > 0.1:
                return "high_latency"
            elif delta_time > HIGH_LATENCY_THRESHOLD:
                return "high_latency"
            elif pd.to_numeric(row["Length"], errors='coerce') > 150 and delta_time > 0.005:
                return "congestion"
            elif "out of order" in info_text:  # Kept for packet disorder
                return "packet_disorder"
            # Excluding packet_loss as per your request
            elif pd.to_numeric(row["RSSI"], errors='coerce') < -70:
                return "signal_issue"
            else:
                return "normal"

        inferred_issue = infer_issue(sample_input)
        print("Inferred Issue:", inferred_issue)

        if prediction != "N/A":
            prediction_proba = loaded_model.predict_proba(X_test)
            print("Prediction Probabilities:")
            for label, prob in zip(loaded_model.classes_, prediction_proba[0]):
                print(f"{label:15}: {prob:.4f}")

except KeyboardInterrupt:
    print("\nStopped packet capture.")
except Exception as e:
    print(f"Error during capture: {e}")